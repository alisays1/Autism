// Export pages
export '/profile_creation/home_page/home_page_widget.dart' show HomePageWidget;
export '/profile_creation/signin/signin_widget.dart' show SigninWidget;
export '/user_account/home_page1/home_page1_widget.dart' show HomePage1Widget;
export '/profile_creation/forget_pass/forget_pass_widget.dart'
    show ForgetPassWidget;
export '/user_account/home_page2/home_page2_widget.dart' show HomePage2Widget;
export '/user_account/home_page3/home_page3_widget.dart' show HomePage3Widget;
export '/user_account/home/home_widget.dart' show HomeWidget;
export '/user_account/update_profile/update_profile_widget.dart'
    show UpdateProfileWidget;
export '/profile_creation/sign_up/sign_up_widget.dart' show SignUpWidget;
export '/user_account/customize_icon/customize_icon_widget.dart'
    show CustomizeIconWidget;
export '/user_account/per_recomend/per_recomend_widget.dart'
    show PerRecomendWidget;
export '/user_account/per_recomend_copy/per_recomend_copy_widget.dart'
    show PerRecomendCopyWidget;
export '/user_account/activity_shapes/activity_shapes_widget.dart'
    show ActivityShapesWidget;
export '/user_account/activity_emotions/activity_emotions_widget.dart'
    show ActivityEmotionsWidget;
export '/user_account/activity_color/activity_color_widget.dart'
    show ActivityColorWidget;
export '/user_account/activity_fruits/activity_fruits_widget.dart'
    show ActivityFruitsWidget;
